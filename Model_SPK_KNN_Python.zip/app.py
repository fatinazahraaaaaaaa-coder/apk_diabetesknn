import math
import pandas as pd
import streamlit as st

st.set_page_config(page_title="SPK Klasifikasi KKN", page_icon="🩺", layout="wide")

DATA = [
    {"Pasien":"P01","Usia":25,"BMI":21.5,"Glukosa":90,"Tekanan Darah":110,"Riwayat Keluarga":0,"Kelas":"Rendah"},
    {"Pasien":"P02","Usia":30,"BMI":23.1,"Glukosa":95,"Tekanan Darah":115,"Riwayat Keluarga":0,"Kelas":"Rendah"},
    {"Pasien":"P03","Usia":35,"BMI":25.0,"Glukosa":105,"Tekanan Darah":120,"Riwayat Keluarga":0,"Kelas":"Rendah"},
    {"Pasien":"P04","Usia":40,"BMI":27.5,"Glukosa":120,"Tekanan Darah":125,"Riwayat Keluarga":1,"Kelas":"Tinggi"},
    {"Pasien":"P05","Usia":45,"BMI":30.2,"Glukosa":140,"Tekanan Darah":135,"Riwayat Keluarga":1,"Kelas":"Tinggi"},
    {"Pasien":"P06","Usia":50,"BMI":31.5,"Glukosa":155,"Tekanan Darah":120,"Riwayat Keluarga":1,"Kelas":"Tinggi"},
    {"Pasien":"P07","Usia":44,"BMI":33.0,"Glukosa":165,"Tekanan Darah":145,"Riwayat Keluarga":1,"Kelas":"Tinggi"},
    {"Pasien":"P08","Usia":28,"BMI":22.5,"Glukosa":92,"Tekanan Darah":112,"Riwayat Keluarga":0,"Kelas":"Rendah"},
    {"Pasien":"P09","Usia":38,"BMI":26.8,"Glukosa":115,"Tekanan Darah":122,"Riwayat Keluarga":0,"Kelas":"Rendah"},
    {"Pasien":"P10","Usia":48,"BMI":29.5,"Glukosa":145,"Tekanan Darah":130,"Riwayat Keluarga":1,"Kelas":"Tinggi"},
]
FEATURES = ["Usia", "BMI", "Glukosa", "Tekanan Darah", "Riwayat Keluarga"]

def hitung_knn(usia, bmi, glukosa, tekanan_darah, riwayat, k=3):
    pasien_baru = [usia, bmi, glukosa, tekanan_darah, riwayat]
    hasil = []
    for row in DATA:
        nilai_lama = [row[f] for f in FEATURES]
        jumlah = sum((a-b)**2 for a,b in zip(nilai_lama, pasien_baru))
        jarak = math.sqrt(jumlah)
        hasil.append({**row, "Jumlah": jumlah, "Jarak": jarak})
    hasil.sort(key=lambda x: x["Jarak"])
    tetangga = hasil[:k]
    suara = {}
    for t in tetangga:
        suara[t["Kelas"]] = suara.get(t["Kelas"], 0) + 1
    kelas = sorted(suara.items(), key=lambda x: (-x[1], x[0]))[0][0]
    return kelas, hasil, tetangga

st.title("🩺 Sistem Pendukung Keputusan — Klasifikasi KKN")
st.caption("Metode K-Nearest Neighbors (KNN) berdasarkan dataset pada file Excel.")
st.warning("Demo pembelajaran, bukan alat diagnosis medis. Hasil tidak menggantikan pemeriksaan tenaga kesehatan.")

tab1, tab2 = st.tabs(["Prediksi Pasien Baru", "Dataset"])
with tab1:
    st.subheader("Masukkan data pasien")
    c1, c2, c3 = st.columns(3)
    with c1:
        usia = st.number_input("Usia (tahun)", min_value=1, max_value=120, value=42)
        bmi = st.number_input("BMI", min_value=1.0, max_value=80.0, value=28.5, step=0.1)
    with c2:
        glukosa = st.number_input("Glukosa", min_value=1, max_value=600, value=130)
        tekanan = st.number_input("Tekanan darah", min_value=1, max_value=300, value=128)
    with c3:
        riwayat_label = st.selectbox("Riwayat keluarga", ["Tidak ada", "Ada"])
        k = st.selectbox("Nilai K (jumlah tetangga)", [1, 3, 5, 7], index=1)
    riwayat = 1 if riwayat_label == "Ada" else 0
    if st.button("Hitung Prediksi", type="primary", use_container_width=True):
        kelas, semua, tetangga = hitung_knn(usia, bmi, glukosa, tekanan, riwayat, k)
        st.success(f"Hasil klasifikasi berdasarkan KNN: **{kelas}**")
        st.subheader(f"{k} tetangga terdekat")
        st.dataframe(pd.DataFrame(tetangga)[["Pasien"] + FEATURES + ["Kelas", "Jumlah", "Jarak"]], use_container_width=True)
        st.subheader("Urutan seluruh jarak")
        st.dataframe(pd.DataFrame(semua)[["Pasien"] + FEATURES + ["Kelas", "Jumlah", "Jarak"]], use_container_width=True)
        st.caption("Rumus: Jumlah = Σ(data lama − data baru)²; Jarak = √Jumlah. Perhitungan mengikuti cara pada Excel dan tidak menggunakan normalisasi.")

with tab2:
    st.subheader("Dataset 10 pasien")
    st.dataframe(pd.DataFrame(DATA), use_container_width=True, hide_index=True)
    st.info("Data contoh diambil dari bagian DATA SET pada file Data_Mining_KKN.xlsx.")
