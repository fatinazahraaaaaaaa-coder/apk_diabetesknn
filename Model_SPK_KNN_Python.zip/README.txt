# Model SPK KNN - Data Mining KKN

Aplikasi Python berbasis Streamlit untuk klasifikasi data pasien menggunakan metode K-Nearest Neighbors (KNN), mengikuti dataset pada `Data_Mining_KKN.xlsx`.

## Cara menjalankan
1. Instal Python 3.10 atau lebih baru.
2. Ekstrak file ZIP ini.
3. Buka Terminal/CMD di folder hasil ekstrak.
4. Jalankan:
   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```
5. Browser akan membuka aplikasi. Masukkan data pasien lalu klik **Hitung Prediksi**.

Dataset berisi 10 data pasien dari bagian DATA SET di file Excel. Nilai awal pasien baru diisi sesuai contoh Excel: usia 42, BMI 28.5, glukosa 130, tekanan darah 128, riwayat keluarga 1. Nilai K awal adalah 3.

Catatan: program ini untuk tugas pembelajaran, bukan alat diagnosis medis. Metode mengikuti perhitungan jarak Euclidean mentah pada Excel, sehingga fitur dengan rentang angka besar bisa sangat memengaruhi jarak.
